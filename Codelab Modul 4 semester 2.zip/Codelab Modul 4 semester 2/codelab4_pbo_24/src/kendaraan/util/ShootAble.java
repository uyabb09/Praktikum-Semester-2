package kendaraan.util;

public interface ShootAble {
    void shoot(String vehicle);
}
