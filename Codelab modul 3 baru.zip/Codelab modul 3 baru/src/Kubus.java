
import java.util.Scanner;

public class Kubus extends BangunRuang {
    Scanner scanner;
    private double sisi;

    public Kubus() {
        throw new Error("Unresolved compilation problems: \n\tImplicit super constructor BangunRuang() is undefined for default constructor. Must define an explicit constructor\n\tThe method input() of type Kubus must override or implement a supertype method\n\tThe method o(String) is undefined for the type System\n\tThe method nextnext() is undefined for the type Scanner\n\tThe method luasaan() is undefined for the type BangunRuang\n\tout cannot be resolved\n\thasil cannot be resolved to a variable\n\thasil cannot be resolved to a variable\n");
    }

    public void input() {
        throw new Error("Unresolved compilation problems: \n\tThe method input() of type Kubus must override or implement a supertype method\n\tThe method o(String) is undefined for the type System\n\tThe method nextnext() is undefined for the type Scanner\n");
    }

    public void luasPermukaan() {
        throw new Error("Unresolved compilation problems: \n\tThe method luasaan() is undefined for the type BangunRuang\n\tout cannot be resolved\n");
    }

    public void volume() {
        throw new Error("Unresolved compilation problems: \n\thasil cannot be resolved to a variable\n\thasil cannot be resolved to a variable\n");
    }
}