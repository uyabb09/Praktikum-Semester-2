
import java.util.Scanner;

public class Tabung extends BangunRuang {
    Scanner scanner;
    private double tinggi;

    public Tabung() {
        throw new Error("Unresolved compilation problems: \n\tImplicit super constructor BangunRuang() is undefined for default constructor. Must define an explicit constructor\n\tConstructor call must be the first statement in a constructor\n\tThe method nextDouble() is undefined for the type Tabung\n\tSyntax error, insert \";\" to complete Statement\n\tjari_jari cannot be resolved to a variable\n\tjari_jari cannot be resolved to a variable\n\tjari_jari cannot be resolved to a variable\n\tSyntax error, insert \"AssignmentOperator Expression\" to complete Expression\n\tluasPermukaan cannot be resolved or is not a field\n\tjari_jari cannot be resolved to a variable\n\tSyntax error, insert \":: IdentifierOrNew\" to complete ReferenceExpression\n\tSyntax error, insert \";\" to complete BlockStatements\n\tSyntax error on token \"hasil\", delete this token\n");
    }

    private double Tabung(String var1) {
        throw new Error("Unresolved compilation problem: \n\tConstructor call must be the first statement in a constructor\n");
    }

    public void inputNilai() {
        throw new Error("Unresolved compilation problems: \n\tThe method nextDouble() is undefined for the type Tabung\n\tSyntax error, insert \";\" to complete Statement\n\tjari_jari cannot be resolved to a variable\n");
    }

    public void luasPermukaan() {
        throw new Error("Unresolved compilation problems: \n\tjari_jari cannot be resolved to a variable\n\tjari_jari cannot be resolved to a variable\n\tSyntax error, insert \"AssignmentOperator Expression\" to complete Expression\n\tluasPermukaan cannot be resolved or is not a field\n");
    }

    public void volume() {
        throw new Error("Unresolved compilation problems: \n\tjari_jari cannot be resolved to a variable\n\tSyntax error, insert \":: IdentifierOrNew\" to complete ReferenceExpression\n\tSyntax error, insert \";\" to complete BlockStatements\n\tSyntax error on token \"hasil\", delete this token\n");
    }
}
